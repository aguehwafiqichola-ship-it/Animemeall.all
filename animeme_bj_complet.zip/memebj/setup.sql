-- ============================================
-- ANIMEME.BJ — Script SQL
-- Importe via phpMyAdmin ou :
-- mysql -u root -p < setup.sql
-- ============================================

CREATE DATABASE IF NOT EXISTS animeme_db
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE animeme_db;

-- UTILISATEURS
CREATE TABLE IF NOT EXISTS users (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    username   VARCHAR(50) NOT NULL UNIQUE,
    email      VARCHAR(100) NOT NULL UNIQUE,
    password   VARCHAR(255) NOT NULL,
    avatar     VARCHAR(255) DEFAULT NULL,
    bio        TEXT DEFAULT NULL,
    role       ENUM('user','admin') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- MÈMES
CREATE TABLE IF NOT EXISTS memes (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    user_id    INT NOT NULL,
    title      VARCHAR(200) NOT NULL,
    top_text   VARCHAR(200) DEFAULT '',
    bot_text   VARCHAR(200) DEFAULT '',
    emoji      VARCHAR(20) DEFAULT '🎌',
    category   VARCHAR(20) DEFAULT 'all',
    image_url  VARCHAR(500) DEFAULT NULL,
    bg_color   VARCHAR(100) DEFAULT 'linear-gradient(135deg,#0d0d30,#1a0a20)',
    views      INT DEFAULT 0,
    is_trending TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_category (category),
    INDEX idx_created (created_at),
    INDEX idx_trending (is_trending)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- LIKES
CREATE TABLE IF NOT EXISTS likes (
    id       INT AUTO_INCREMENT PRIMARY KEY,
    meme_id  INT NOT NULL,
    user_id  INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_like (meme_id, user_id),
    FOREIGN KEY (meme_id) REFERENCES memes(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- RÉACTIONS FEU 🔥
CREATE TABLE IF NOT EXISTS fires (
    id       INT AUTO_INCREMENT PRIMARY KEY,
    meme_id  INT NOT NULL,
    user_id  INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_fire (meme_id, user_id),
    FOREIGN KEY (meme_id) REFERENCES memes(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- COMMENTAIRES
CREATE TABLE IF NOT EXISTS comments (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    meme_id    INT NOT NULL,
    user_id    INT NOT NULL,
    content    TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (meme_id) REFERENCES memes(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_meme (meme_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- DONNÉES D'EXEMPLE
INSERT INTO users (username, email, password, bio) VALUES
('SamouraiMot', 'samurai@animeme.bj', '$2y$10$example_hash_1', 'Otaku pro | Demon Slayer fan 🇧🇯'),
('OtakuKing', 'otaku@animeme.bj', '$2y$10$example_hash_2', 'One Piece forever 🏴‍☠️'),
('AnimeGod', 'god@animeme.bj', '$2y$10$example_hash_3', 'Je regarde tout les animes 🎌');

INSERT INTO memes (user_id, title, top_text, bot_text, emoji, category, is_trending, views) VALUES
(1, 'Quand Tanjiro arrive trop tard', 'LE BOSS AVANT LE COMBAT', 'LE BOSS APRÈS 5 MINS DE TANJIRO', '⚔️', 'ds', 1, 892),
(2, 'Luffy face à la nourriture', 'MOI FACE À MON RÉGIME', 'LE BUFFET AU FOND DE LA SALLE', '🏴‍☠️', 'op', 1, 540),
(1, 'Naruto Talk no Jutsu', 'ENNEMIS QUI VEULENT DÉTRUIRE LE MONDE', 'NARUTO : "CROIS EN TOI, BRO"', '🍃', 'nrt', 1, 987),
(3, 'Gojo vs le comité', 'GOJO : JE SUIS LE PLUS FORT', 'LE COMITÉ ONGOKU : *sigh*', '💜', 'jjk', 1, 1580),
(2, 'Zoro qui cherche sa direction', 'GPS : "TOURNEZ À GAUCHE"', 'ZORO : ok (tourne à droite)', '🏴‍☠️', 'op', 0, 820);
