<?php require_once 'config.php'; $user = current_user(); ?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>⚔️ ANIMEME.BJ — Mèmes Anime du Bénin</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=Cinzel+Decorative:wght@700;900&family=Rajdhani:wght@400;600;700&display=swap');
*{margin:0;padding:0;box-sizing:border-box;}
:root{
  --bg:#05050f;--bg2:#0a0a1a;--card:#0d0d20;--card2:#12122a;
  --border:#1e1e4a;--border2:#2a2a6a;--text:#e8e8ff;--muted:#6666aa;
  --red:#e63946;--red2:#ff6b7a;--gold:#f4a261;--gold2:#ffd166;
  --blue:#457b9d;--blue2:#74c0fc;--purple:#7b2d8b;--purple2:#c77dff;
  --teal:#06d6a0;
}
body{background:var(--bg);color:var(--text);font-family:'Rajdhani',sans-serif;min-height:100vh;}
body::before{content:'';position:fixed;inset:0;z-index:0;
  background:radial-gradient(ellipse at 20% 20%,rgba(230,57,70,.08) 0%,transparent 50%),
             radial-gradient(ellipse at 80% 80%,rgba(123,45,139,.08) 0%,transparent 50%);
  animation:bgP 8s ease-in-out infinite alternate;pointer-events:none;}
@keyframes bgP{from{opacity:.7}to{opacity:1}}

.flames{position:fixed;inset:0;pointer-events:none;z-index:1;overflow:hidden;}
.flame{position:absolute;bottom:-20px;border-radius:50%;animation:rF linear infinite;opacity:0;}
@keyframes rF{0%{transform:translateY(0);opacity:.8}100%{transform:translateY(-100vh);opacity:0}}

nav{position:sticky;top:0;z-index:100;background:rgba(5,5,15,.95);border-bottom:1px solid var(--border2);
  padding:0 1.5rem;display:flex;align-items:center;justify-content:space-between;height:64px;backdrop-filter:blur(12px);}
nav::after{content:'';position:absolute;bottom:0;left:0;right:0;height:2px;
  background:linear-gradient(90deg,var(--red),var(--gold),var(--purple),var(--red));
  background-size:200%;animation:sh 3s linear infinite;}
@keyframes sh{0%{background-position:0%}100%{background-position:200%}}
.logo{font-family:'Cinzel Decorative',cursive;font-size:20px;letter-spacing:3px;
  background:linear-gradient(135deg,var(--red2),var(--gold2));-webkit-background-clip:text;-webkit-text-fill-color:transparent;
  filter:drop-shadow(0 0 8px rgba(230,57,70,.6));}
.nav-tabs{display:flex;gap:2px;}
.nav-tab{background:none;border:none;color:var(--muted);padding:8px 13px;border-radius:6px;cursor:pointer;
  font-family:'Rajdhani',sans-serif;font-weight:700;font-size:13px;transition:all .2s;}
.nav-tab:hover{color:var(--text);background:rgba(255,255,255,.05);}
.nav-tab.active{background:rgba(230,57,70,.2);color:var(--red2);box-shadow:inset 0 0 0 1px rgba(230,57,70,.4);}
.nav-right{display:flex;align-items:center;gap:10px;}
.btn-ln{background:none;border:1px solid var(--border2);color:var(--text);padding:7px 15px;
  border-radius:6px;cursor:pointer;font-family:'Rajdhani',sans-serif;font-weight:700;font-size:13px;transition:all .2s;}
.btn-ln:hover{border-color:var(--gold);color:var(--gold);}
.btn-up{background:linear-gradient(135deg,var(--red),#c1121f);border:none;color:#fff;
  padding:8px 16px;border-radius:6px;cursor:pointer;font-family:'Rajdhani',sans-serif;
  font-weight:700;font-size:13px;transition:all .2s;box-shadow:0 0 20px rgba(230,57,70,.5);}
.btn-up:hover{transform:scale(1.05);}

.layout{display:flex;max-width:1120px;margin:0 auto;gap:1.2rem;padding:1.2rem;position:relative;z-index:2;}

.sidebar{width:195px;flex-shrink:0;}
.sb-sec{background:var(--card);border:1px solid var(--border);border-radius:10px;padding:1rem;margin-bottom:1rem;}
.sb-title{font-size:10px;text-transform:uppercase;letter-spacing:2px;color:var(--gold);margin-bottom:10px;font-weight:700;}
.sb-btn{display:flex;align-items:center;gap:8px;width:100%;background:none;border:none;color:var(--muted);
  padding:8px 10px;border-radius:7px;cursor:pointer;font-family:'Rajdhani',sans-serif;
  font-size:13px;font-weight:700;text-align:left;transition:all .2s;margin-bottom:2px;}
.sb-btn:hover{background:rgba(255,255,255,.04);color:var(--text);}
.sb-btn.active{background:rgba(230,57,70,.15);color:var(--red2);border-left:2px solid var(--red);}
.tags{display:flex;flex-wrap:wrap;gap:5px;}
.tag{background:var(--card2);border:1px solid var(--border);color:var(--muted);
  padding:4px 9px;border-radius:20px;font-size:11px;font-weight:700;cursor:pointer;transition:all .2s;}
.tag:hover,.tag.active{background:rgba(230,57,70,.2);border-color:var(--red);color:var(--red2);}
.stat-r{display:flex;justify-content:space-between;padding:4px 0;font-size:12px;}
.stat-v{font-weight:700;color:var(--gold2);}

.main{flex:1;min-width:0;}
.page{display:none;}.page.active{display:block;}

.fc{display:flex;gap:8px;margin-bottom:1rem;align-items:center;}
.sort-btn{background:var(--card);border:1px solid var(--border);color:var(--muted);
  padding:7px 14px;border-radius:7px;cursor:pointer;font-family:'Rajdhani',sans-serif;font-weight:700;font-size:13px;transition:all .2s;}
.sort-btn:hover{border-color:var(--gold);color:var(--gold);}
.sort-btn.active{background:rgba(244,162,97,.15);border-color:var(--gold);color:var(--gold2);}
.srch{flex:1;background:var(--card);border:1px solid var(--border);color:var(--text);
  padding:7px 14px;border-radius:7px;font-family:'Rajdhani',sans-serif;font-size:13px;outline:none;transition:border-color .2s;}
.srch:focus{border-color:var(--blue2);}
.srch::placeholder{color:var(--muted);}

.mgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(270px,1fr));gap:1rem;}
.mcard{background:var(--card);border:1px solid var(--border);border-radius:12px;overflow:hidden;transition:all .3s;animation:fU .4s ease both;}
@keyframes fU{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}
.mcard:hover{border-color:var(--red);transform:translateY(-4px);box-shadow:0 8px 30px rgba(230,57,70,.25);}
.mcard.trend{border-color:rgba(244,162,97,.5);}
.mcard.trend:hover{border-color:var(--gold);box-shadow:0 8px 30px rgba(244,162,97,.25);}

.mvis{width:100%;aspect-ratio:4/3;display:flex;flex-direction:column;align-items:center;justify-content:center;
  position:relative;overflow:hidden;font-family:'Cinzel Decorative',cursive;text-align:center;padding:1rem;}
.mpat{position:absolute;inset:0;opacity:.06;background-image:repeating-linear-gradient(45deg,#fff 0,#fff 1px,transparent 0,transparent 50%);background-size:20px 20px;}
.mtop{position:absolute;top:10px;left:0;right:0;padding:0 10px;z-index:2;font-size:14px;color:#fff;
  text-shadow:2px 2px 0 #000,-2px -2px 0 #000,2px -2px 0 #000,-2px 2px 0 #000;letter-spacing:1px;}
.mbot{position:absolute;bottom:10px;left:0;right:0;padding:0 10px;z-index:2;font-size:14px;color:#fff;
  text-shadow:2px 2px 0 #000,-2px -2px 0 #000,2px -2px 0 #000,-2px 2px 0 #000;letter-spacing:1px;}
.moji{font-size:54px;z-index:2;position:relative;filter:drop-shadow(0 0 12px rgba(0,0,0,.8));}
.tbadge{position:absolute;top:8px;right:8px;z-index:3;
  background:linear-gradient(135deg,var(--red),var(--gold));color:#fff;
  font-size:10px;font-weight:700;padding:3px 9px;border-radius:20px;font-family:'Rajdhani',sans-serif;}
.sbadge{position:absolute;top:8px;left:8px;z-index:3;
  background:rgba(0,0,0,.7);border:1px solid rgba(255,255,255,.2);
  color:var(--gold2);font-size:10px;font-weight:700;padding:3px 9px;border-radius:20px;font-family:'Rajdhani',sans-serif;}
.mmeta{padding:8px 12px 4px;display:flex;align-items:center;gap:8px;}
.mav{width:22px;height:22px;border-radius:50%;display:flex;align-items:center;justify-content:center;
  font-size:10px;font-weight:900;flex-shrink:0;background:linear-gradient(135deg,var(--red),var(--purple));color:#fff;}
.maname{font-size:11px;color:var(--muted);font-weight:600;}
.mviews{font-size:11px;color:var(--muted);margin-left:auto;}
.mfoot{padding:8px 12px;display:flex;align-items:center;justify-content:space-between;gap:8px;}
.mtitle{font-size:13px;font-weight:700;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.macts{display:flex;gap:5px;flex-shrink:0;}
.abt{background:var(--card2);border:1px solid var(--border);color:var(--muted);
  padding:5px 9px;border-radius:6px;cursor:pointer;font-size:12px;font-weight:700;
  display:flex;align-items:center;gap:3px;transition:all .2s;font-family:'Rajdhani',sans-serif;}
.abt:hover{border-color:var(--red);color:var(--red2);}
.abt.liked{background:rgba(230,57,70,.15);border-color:var(--red);color:var(--red2);}
.abt.fired{background:rgba(244,162,97,.15);border-color:var(--gold);color:var(--gold2);}

.mcoms{border-top:1px solid var(--border);padding:10px 12px;display:none;}
.mcoms.open{display:block;}
.clist{max-height:130px;overflow-y:auto;margin-bottom:8px;}
.ci{display:flex;gap:6px;margin-bottom:6px;font-size:12px;}
.cau{color:var(--gold2);font-weight:700;flex-shrink:0;}
.ct{color:var(--text);}
.crow{display:flex;gap:6px;}
.cinp{flex:1;background:var(--card2);border:1px solid var(--border);color:var(--text);
  padding:6px 10px;border-radius:6px;font-size:12px;font-family:'Rajdhani',sans-serif;outline:none;}
.cinp::placeholder{color:var(--muted);}
.csend{background:var(--red);border:none;color:#fff;padding:6px 12px;border-radius:6px;
  cursor:pointer;font-size:12px;font-weight:700;font-family:'Rajdhani',sans-serif;transition:all .2s;}
.csend:hover{background:#c1121f;}

/* TRENDING */
.thero{background:linear-gradient(135deg,rgba(230,57,70,.15),rgba(123,45,139,.15));
  border:1px solid rgba(230,57,70,.3);border-radius:14px;padding:1.5rem;margin-bottom:1rem;position:relative;overflow:hidden;}
.thero::before{content:'⚡';font-size:80px;position:absolute;right:20px;top:50%;transform:translateY(-50%);opacity:.08;}
.therot{font-family:'Cinzel Decorative',cursive;font-size:22px;letter-spacing:2px;
  background:linear-gradient(135deg,var(--red2),var(--gold2));-webkit-background-clip:text;-webkit-text-fill-color:transparent;}
.theros{color:var(--muted);font-size:13px;}

/* AI */
.aiwrap{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:2rem;max-width:660px;margin:0 auto;}
.aibadge{display:inline-flex;align-items:center;gap:6px;
  background:linear-gradient(135deg,rgba(116,192,252,.2),rgba(199,125,255,.2));
  border:1px solid rgba(116,192,252,.3);color:var(--blue2);font-size:11px;font-weight:700;
  padding:4px 12px;border-radius:20px;margin-bottom:10px;letter-spacing:1px;}
.aititle{font-family:'Cinzel Decorative',cursive;font-size:26px;letter-spacing:2px;
  background:linear-gradient(135deg,var(--blue2),var(--purple2));-webkit-background-clip:text;-webkit-text-fill-color:transparent;margin-bottom:6px;}
.aisub{color:var(--muted);font-size:13px;margin-bottom:1.2rem;font-weight:600;}
.chips{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:1rem;}
.chip{background:var(--card2);border:1px solid var(--border);color:var(--muted);
  padding:5px 13px;border-radius:20px;font-size:12px;font-weight:700;cursor:pointer;transition:all .2s;}
.chip:hover{border-color:var(--purple2);color:var(--purple2);background:rgba(199,125,255,.1);}
.airow{display:flex;gap:8px;margin-bottom:1.5rem;}
.aiinp{flex:1;background:var(--card2);border:1px solid var(--border);color:var(--text);
  padding:12px 16px;border-radius:8px;font-family:'Rajdhani',sans-serif;font-size:14px;outline:none;transition:border-color .2s;}
.aiinp:focus{border-color:var(--purple2);}
.aiinp::placeholder{color:var(--muted);}
.aigbtn{background:linear-gradient(135deg,var(--blue2),var(--purple2));border:none;color:#fff;
  padding:12px 20px;border-radius:8px;font-family:'Cinzel Decorative',cursive;font-size:13px;
  letter-spacing:1px;cursor:pointer;transition:all .2s;box-shadow:0 0 20px rgba(116,192,252,.3);}
.aigbtn:hover{transform:scale(1.05);}
.aigbtn:disabled{background:var(--border);color:var(--muted);transform:none;cursor:not-allowed;box-shadow:none;}
.aires{display:none;background:var(--card2);border:1px solid var(--border);border-radius:10px;overflow:hidden;}
.aires.show{display:block;animation:fU .4s ease;}
.aiprev{aspect-ratio:4/3;display:flex;flex-direction:column;align-items:center;justify-content:center;
  position:relative;overflow:hidden;font-family:'Cinzel Decorative',cursive;text-align:center;padding:1.5rem;}
.ait{font-size:20px;color:#fff;text-shadow:2px 2px 0 #000,-2px -2px 0 #000,2px -2px 0 #000,-2px 2px 0 #000;margin-bottom:12px;letter-spacing:1px;}
.aie{font-size:70px;filter:drop-shadow(0 0 15px rgba(0,0,0,.9));}
.aib{font-size:20px;color:#fff;text-shadow:2px 2px 0 #000,-2px -2px 0 #000,2px -2px 0 #000,-2px 2px 0 #000;margin-top:12px;letter-spacing:1px;}
.aifoot{padding:12px 16px;background:var(--card);}
.aicap{font-size:13px;color:var(--text);font-weight:700;margin-bottom:10px;}
.aiacts{display:flex;gap:8px;}
.aiac{flex:1;padding:9px;border-radius:7px;font-family:'Rajdhani',sans-serif;font-weight:700;
  font-size:13px;cursor:pointer;transition:all .2s;border:1px solid var(--border);background:var(--card2);color:var(--text);}
.aiac.prim{background:linear-gradient(135deg,var(--red),#c1121f);border-color:var(--red);color:#fff;}
.aiac:hover{transform:scale(1.03);}

/* UPLOAD */
.upwrap{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:2rem;max-width:600px;margin:0 auto;}
.uptitle{font-family:'Cinzel Decorative',cursive;font-size:22px;letter-spacing:2px;color:var(--red2);margin-bottom:1.5rem;}
.fg{margin-bottom:1.1rem;}
.fl{display:block;font-size:11px;font-weight:700;color:var(--gold);text-transform:uppercase;letter-spacing:1.5px;margin-bottom:5px;}
.fi{width:100%;background:var(--card2);border:1px solid var(--border);color:var(--text);
  padding:10px 14px;border-radius:8px;font-family:'Rajdhani',sans-serif;font-size:14px;outline:none;transition:border-color .2s;}
.fi:focus{border-color:var(--red);}
.fi::placeholder{color:var(--muted);}
.tsel{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:1.1rem;}
.tbtn{background:var(--card2);border:1px solid var(--border);color:var(--muted);padding:10px;
  border-radius:8px;cursor:pointer;font-family:'Rajdhani',sans-serif;font-weight:700;font-size:12px;text-align:center;transition:all .2s;}
.tbtn.active{background:rgba(230,57,70,.15);border-color:var(--red);color:var(--red2);}
.dz{border:2px dashed var(--border2);border-radius:10px;padding:2.5rem;text-align:center;cursor:pointer;transition:all .2s;background:var(--card2);}
.dz:hover{border-color:var(--red);background:rgba(230,57,70,.05);}
.dico{font-size:36px;margin-bottom:8px;}
.dtxt{color:var(--muted);font-size:13px;font-weight:700;}
.dtxt span{color:var(--red2);}
.dprev{width:100%;max-height:180px;object-fit:contain;border-radius:8px;margin-top:10px;display:none;}
.bpub{width:100%;background:linear-gradient(135deg,var(--red),#c1121f);border:none;color:#fff;
  padding:14px;border-radius:9px;font-family:'Cinzel Decorative',cursive;font-size:18px;
  letter-spacing:2px;cursor:pointer;transition:all .2s;box-shadow:0 0 20px rgba(230,57,70,.5);}
.bpub:hover{transform:scale(1.02);}

/* PROFILE */
.phero{background:linear-gradient(135deg,rgba(230,57,70,.1),rgba(123,45,139,.1));
  border:1px solid var(--border);border-radius:14px;padding:1.5rem;margin-bottom:1rem;display:flex;align-items:center;gap:1.5rem;}
.pav{width:72px;height:72px;border-radius:50%;display:flex;align-items:center;justify-content:center;
  font-family:'Cinzel Decorative',cursive;font-size:22px;background:linear-gradient(135deg,var(--red),var(--purple));
  color:#fff;flex-shrink:0;box-shadow:0 0 20px rgba(230,57,70,.4);}
.pname{font-family:'Cinzel Decorative',cursive;font-size:20px;letter-spacing:1px;}
.pbio{color:var(--muted);font-size:13px;margin-top:3px;font-weight:600;}
.pstats{display:flex;gap:1.5rem;margin-top:10px;}
.psn{font-family:'Cinzel Decorative',cursive;font-size:22px;background:linear-gradient(135deg,var(--red2),var(--gold2));-webkit-background-clip:text;-webkit-text-fill-color:transparent;}
.psl{font-size:11px;color:var(--muted);font-weight:700;text-transform:uppercase;letter-spacing:1px;}
.stitle{font-family:'Cinzel Decorative',cursive;font-size:16px;letter-spacing:1.5px;color:var(--gold2);margin-bottom:.8rem;}

/* MODAL */
.mov{display:none;position:fixed;inset:0;background:rgba(0,0,0,.85);z-index:200;align-items:center;justify-content:center;backdrop-filter:blur(4px);}
.mov.open{display:flex;}
.modal{background:var(--card);border:1px solid var(--border2);border-radius:14px;padding:2rem;width:360px;animation:fU .3s ease;position:relative;}
.mtitle{font-family:'Cinzel Decorative',cursive;font-size:22px;letter-spacing:2px;color:var(--red2);margin-bottom:1.5rem;text-align:center;}
.mtabs{display:flex;margin-bottom:1.5rem;border-bottom:1px solid var(--border);}
.mtab{flex:1;background:none;border:none;color:var(--muted);padding:10px;cursor:pointer;
  font-family:'Rajdhani',sans-serif;font-weight:700;font-size:14px;border-bottom:2px solid transparent;margin-bottom:-1px;transition:all .2s;}
.mtab.active{color:var(--red2);border-bottom-color:var(--red);}
.minp{width:100%;background:var(--card2);border:1px solid var(--border);color:var(--text);
  padding:11px 14px;border-radius:8px;font-family:'Rajdhani',sans-serif;font-size:14px;outline:none;margin-bottom:10px;transition:border-color .2s;}
.minp:focus{border-color:var(--red);}
.minp::placeholder{color:var(--muted);}
.msub{width:100%;background:linear-gradient(135deg,var(--red),#c1121f);border:none;color:#fff;
  padding:13px;border-radius:8px;font-family:'Cinzel Decorative',cursive;font-size:16px;
  letter-spacing:2px;cursor:pointer;margin-top:6px;transition:all .2s;}
.msub:hover{box-shadow:0 0 30px rgba(230,57,70,.8);}
.mclose{position:absolute;top:12px;right:14px;background:none;border:none;color:var(--muted);font-size:20px;cursor:pointer;}

.toast{position:fixed;bottom:20px;right:20px;z-index:999;background:var(--card2);border:1px solid var(--border2);
  color:var(--text);padding:12px 18px;border-radius:9px;font-size:13px;font-weight:700;
  transform:translateY(80px);opacity:0;transition:all .3s;font-family:'Rajdhani',sans-serif;}
.toast.show{transform:translateY(0);opacity:1;}
.toast.r{border-color:var(--red);color:var(--red2);}
.toast.g{border-color:var(--teal);color:var(--teal);}
.toast.gold{border-color:var(--gold);color:var(--gold2);}

.lmw{text-align:center;margin-top:1.5rem;}
.dots{display:inline-flex;gap:4px;align-items:center;}
.dot{width:5px;height:5px;background:#fff;border-radius:50%;animation:bop 1.2s infinite;}
.dot:nth-child(2){animation-delay:.2s}.dot:nth-child(3){animation-delay:.4s}
@keyframes bop{0%,80%,100%{transform:scale(.5);opacity:.3}40%{transform:scale(1);opacity:1}}
.spin{display:inline-block;animation:spin 1s linear infinite;}
@keyframes spin{to{transform:rotate(360deg)}}
@media(max-width:700px){.sidebar{display:none}.mgrid{grid-template-columns:1fr}.layout{padding:.8rem}}
</style>
</head>
<body>

<div class="flames" id="flames"></div>

<!-- MODAL -->
<div class="mov" id="mov">
  <div class="modal">
    <button class="mclose" onclick="closeMod()">✕</button>
    <div class="mtitle">⚔️ CONNEXION</div>
    <div class="mtabs">
      <button class="mtab active" id="tL" onclick="swTab('l')">Connexion</button>
      <button class="mtab" id="tR" onclick="swTab('r')">Inscription</button>
    </div>
    <div id="fL">
      <input class="minp" type="text" placeholder="Pseudo" id="lU">
      <input class="minp" type="password" placeholder="Mot de passe" id="lP">
      <button class="msub" onclick="doLogin()">⚡ SE CONNECTER</button>
    </div>
    <div id="fR" style="display:none">
      <input class="minp" type="text" placeholder="Pseudo" id="rU">
      <input class="minp" type="email" placeholder="Email" id="rE">
      <input class="minp" type="password" placeholder="Mot de passe (min 6)" id="rP">
      <button class="msub" onclick="doReg()">🔥 S'INSCRIRE</button>
    </div>
  </div>
</div>

<div class="toast" id="toast"></div>

<nav>
  <div class="logo">⚔️ ANIMEME.BJ</div>
  <div class="nav-tabs">
    <button class="nav-tab active" onclick="goP('feed')">🏠 Feed</button>
    <button class="nav-tab" onclick="goP('trend')">🔥 Trending</button>
    <button class="nav-tab" onclick="goP('ai')">🤖 IA Mèmes</button>
    <button class="nav-tab" onclick="goP('up')">📤 Upload</button>
    <button class="nav-tab" onclick="goP('prof')">⚔️ Profil</button>
  </div>
  <div class="nav-right">
    <span style="font-size:12px;color:var(--gold2)" id="nU">
      <?= $user ? '⚔️ '.htmlspecialchars($user['username']) : '' ?>
    </span>
    <?php if($user): ?>
      <button class="btn-ln" onclick="doLogout()">Déconnexion</button>
    <?php else: ?>
      <button class="btn-ln" onclick="openMod()" id="lBtn">Connexion</button>
    <?php endif; ?>
    <button class="btn-up" onclick="goP('up')">+ Upload</button>
  </div>
</nav>

<div class="layout">
  <aside class="sidebar">
    <div class="sb-sec">
      <div class="sb-title">⚔️ Navigation</div>
      <button class="sb-btn active" onclick="goP('feed');sbA(this)">🏠 Feed</button>
      <button class="sb-btn" onclick="goP('trend');sbA(this)">🔥 Trending</button>
      <button class="sb-btn" onclick="goP('ai');sbA(this)">🤖 IA Génér.</button>
      <button class="sb-btn" onclick="goP('up');sbA(this)">📤 Upload</button>
      <button class="sb-btn" onclick="goP('prof');sbA(this)">⚔️ Profil</button>
    </div>
    <div class="sb-sec">
      <div class="sb-title">🎌 Séries</div>
      <div class="tags">
        <span class="tag active" onclick="doTag(this,'all')">Tout</span>
        <span class="tag" onclick="doTag(this,'ds')">Demon Slayer</span>
        <span class="tag" onclick="doTag(this,'op')">One Piece</span>
        <span class="tag" onclick="doTag(this,'aot')">AOT</span>
        <span class="tag" onclick="doTag(this,'nrt')">Naruto</span>
        <span class="tag" onclick="doTag(this,'jjk')">JJK</span>
        <span class="tag" onclick="doTag(this,'hxh')">HxH</span>
        <span class="tag" onclick="doTag(this,'db')">Dragon Ball</span>
        <span class="tag" onclick="doTag(this,'bl')">Bleach</span>
      </div>
    </div>
    <div class="sb-sec">
      <div class="sb-title">📊 Stats</div>
      <div class="stat-r"><span style="font-size:12px;color:var(--muted)">😂 Mèmes</span><span class="stat-v" id="sTot">—</span></div>
      <div class="stat-r"><span style="font-size:12px;color:var(--muted)">❤️ Likes</span><span class="stat-v" id="sLik">—</span></div>
      <div class="stat-r"><span style="font-size:12px;color:var(--muted)">👁️ Vues</span><span class="stat-v" id="sVue">—</span></div>
    </div>
  </aside>

  <main class="main">

    <!-- FEED -->
    <div class="page active" id="page-feed">
      <div class="fc">
        <button class="sort-btn active" onclick="setSort(this,'new')">🕒 Récents</button>
        <button class="sort-btn" onclick="setSort(this,'top')">🔥 Populaires</button>
        <input class="srch" type="text" placeholder="🔍 Chercher..." id="srch" oninput="doSearch()">
      </div>
      <div class="mgrid" id="feedG"><div style="color:var(--muted);text-align:center;padding:2rem"><span class="spin">⚔️</span> Chargement...</div></div>
      <div class="lmw"><button class="sort-btn" onclick="loadMore()">⬇ Charger plus</button></div>
    </div>

    <!-- TRENDING -->
    <div class="page" id="page-trend">
      <div class="thero">
        <div class="therot">⚡ TRENDING ANIME MÈMES</div>
        <div class="theros">Les mèmes qui font rage dans la communauté anime</div>
      </div>
      <div class="mgrid" id="trendG"></div>
    </div>

    <!-- AI -->
    <div class="page" id="page-ai">
      <div class="aiwrap">
        <div class="aibadge">✨ POWERED BY ANIMEME AI</div>
        <div class="aititle">GÉNÉRATEUR IA</div>
        <div class="aisub">Décris une scène ou un personnage — l'IA crée le mème ⚡</div>
        <div class="chips">
          <span class="chip" onclick="setC(this)">Tanjiro vs boss final 😤</span>
          <span class="chip" onclick="setC(this)">Luffy qui mange encore</span>
          <span class="chip" onclick="setC(this)">Goku en training</span>
          <span class="chip" onclick="setC(this)">Naruto rate un jutsu</span>
          <span class="chip" onclick="setC(this)">Mikasa protège Eren</span>
          <span class="chip" onclick="setC(this)">Gojo confident</span>
          <span class="chip" onclick="setC(this)">Zoro qui se perd</span>
          <span class="chip" onclick="setC(this)">Light vs L aux échecs</span>
        </div>
        <div class="airow">
          <input class="aiinp" type="text" id="aiI" placeholder="Ex: Naruto rate un jutsu...">
          <button class="aigbtn" id="aiBt" onclick="genAI()">⚡ GÉNÉRER</button>
        </div>
        <div class="aires" id="aiR">
          <div class="aiprev" id="aiPv">
            <div class="mpat"></div>
            <div class="ait" id="aiT"></div>
            <div class="aie" id="aiE"></div>
            <div class="aib" id="aiB"></div>
          </div>
          <div class="aifoot">
            <div class="aicap" id="aiC"></div>
            <div class="aiacts">
              <button class="aiac" onclick="reGen()">🔄 Régénérer</button>
              <button class="aiac" onclick="saveAI()">💾 Sauvegarder</button>
              <button class="aiac prim" onclick="shareAI()">📤 Partager</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- UPLOAD -->
    <div class="page" id="page-up">
      <div class="upwrap">
        <div class="uptitle">⚔️ UPLOADER UN MÈME</div>
        <div class="fg">
          <label class="fl">Type</label>
          <div class="tsel">
            <button class="tbtn active" onclick="selT(this)">🖼 Image</button>
            <button class="tbtn" onclick="selT(this)">✍ Texte</button>
            <button class="tbtn" onclick="selT(this)">🎬 GIF</button>
          </div>
        </div>
        <div class="fg" id="dzW">
          <label class="fl">Image</label>
          <div class="dz" onclick="document.getElementById('fI').click()" id="dz">
            <div class="dico">🖼️</div>
            <div class="dtxt">Clique ou <span>glisse</span> ton image</div>
            <div style="font-size:11px;color:var(--muted);margin-top:4px">PNG, JPG, GIF, WEBP — max 10MB</div>
            <img class="dprev" id="dprev">
          </div>
          <input type="file" id="fI" style="display:none" accept="image/*" onchange="prevF(this)">
        </div>
        <div class="fg"><label class="fl">Titre</label><input class="fi" type="text" id="uT" placeholder="Ex: Tanjiro face au boss final..."></div>
        <div class="fg"><label class="fl">Texte haut</label><input class="fi" type="text" id="uTp" placeholder="Texte en haut du mème"></div>
        <div class="fg"><label class="fl">Texte bas</label><input class="fi" type="text" id="uBt" placeholder="Texte en bas du mème"></div>
        <div class="fg">
          <label class="fl">Série</label>
          <select class="fi" id="uCat">
            <option value="all">🎌 Général Anime</option>
            <option value="ds">⚔️ Demon Slayer</option>
            <option value="op">🏴‍☠️ One Piece</option>
            <option value="aot">🌑 Attack on Titan</option>
            <option value="nrt">🍃 Naruto</option>
            <option value="jjk">💜 Jujutsu Kaisen</option>
            <option value="hxh">⭐ Hunter x Hunter</option>
            <option value="db">💥 Dragon Ball</option>
            <option value="bl">⚡ Bleach</option>
          </select>
        </div>
        <button class="bpub" onclick="doUpload()">⚔️ PUBLIER LE MÈME</button>
      </div>
    </div>

    <!-- PROFILE -->
    <div class="page" id="page-prof">
      <?php if($user): ?>
      <div class="phero">
        <div class="pav" id="pAv"><?= strtoupper($user['username'][0]) ?></div>
        <div>
          <div class="pname" id="pN"><?= htmlspecialchars($user['username']) ?> ⚔️</div>
          <div class="pbio"><?= htmlspecialchars($user['bio'] ?? 'Otaku depuis toujours 🎌') ?></div>
          <div class="pstats">
            <div><div class="psn" id="pM">0</div><div class="psl">Mèmes</div></div>
            <div><div class="psn" id="pL">0</div><div class="psl">Likes</div></div>
            <div><div class="psn" id="pV">0</div><div class="psl">Vues</div></div>
          </div>
        </div>
      </div>
      <?php else: ?>
      <div style="text-align:center;padding:3rem;color:var(--muted)">
        <div style="font-size:48px;margin-bottom:1rem">⚔️</div>
        <div style="font-family:'Cinzel Decorative',cursive;font-size:18px;margin-bottom:1rem">Connecte-toi pour voir ton profil</div>
        <button class="bpub" style="max-width:250px" onclick="openMod()">🔑 SE CONNECTER</button>
      </div>
      <?php endif; ?>
      <div class="stitle" style="margin-top:1rem">⚔️ MES MÈMES</div>
      <div class="mgrid" id="profG"></div>
    </div>

  </main>
</div>

<script>
// ===== CONFIG =====
const API = 'api/';
const SN = {ds:'Demon Slayer',op:'One Piece',aot:'AOT',nrt:'Naruto',jjk:'JJK',hxh:'HxH',db:'Dragon Ball',bl:'Bleach',all:'Anime'};
const SE = {ds:'⚔️',op:'🏴‍☠️',aot:'🌑',nrt:'🍃',jjk:'💜',hxh:'⭐',db:'💥',bl:'⚡',all:'🎌'};
const BG = ['linear-gradient(135deg,#0d0d30,#1a0a20)','linear-gradient(135deg,#200a0a,#0d0d20)','linear-gradient(135deg,#0a2010,#0d1a30)','linear-gradient(135deg,#1a0a30,#0a1020)','linear-gradient(135deg,#200a10,#0a0a20)','linear-gradient(135deg,#0a1030,#200a20)'];
const AI_T = [
  {top:'AVANT LE COMBAT',bot:'PENDANT LE COMBAT',e:'⚔️',bg:BG[0],cap:'Tanjiro - confiance vs réalité'},
  {top:'LUFFY MANGE SON 5ème PLAT',bot:'LUFFY : "J\'AI ENCORE FAIM"',e:'🏴‍☠️',bg:BG[1],cap:'L\'équipage de Luffy chaque épisode'},
  {top:'GOKU VOIT UN ENNEMI FORT',bot:'GOKU : ON SE BATS MAINTENANT ?',e:'💥',bg:BG[2],cap:'Chi-Chi quelque part qui pleure'},
  {top:'NARUTO : "JE DEVIENDRAI HOKAGE"',bot:'KAKASHI : *sigh*',e:'🍃',bg:BG[3],cap:'Chaque épisode de Naruto Shippuden'},
  {top:'MIKASA : EREN EST EN DANGER',bot:'MIKASA : *massacre 50 titans*',e:'🌑',bg:BG[4],cap:'Mode berserker activé'},
  {top:'GOJO : T\'AS PAS UNE CHANCE',bot:'GOJO : *infinity*',e:'💜',bg:BG[5],cap:'Personne bat Gojo sauf le scénario'},
  {top:'ZORO CHERCHE LES TOILETTES',bot:'ZORO : *se retrouve au Japon*',e:'🏴‍☠️',bg:BG[0],cap:'GPS activé : erreur critique'},
  {top:'MOI QUI COMMENCE UN ANIME',bot:'MOI 3H PLUS TARD : ENCORE UN ÉP',e:'🎌',bg:BG[1],cap:'La vraie malédiction de l\'anime'},
];

let sort='new', tag='all', offset=0, lastP='';
let loggedIn = <?= $user ? 'true' : 'false' ?>;

// ===== FLAMES =====
(function(){
  const c=document.getElementById('flames');
  const cols=['#e63946','#f4a261','#ffd166','#c77dff','#74c0fc'];
  for(let i=0;i<18;i++){
    const d=document.createElement('div'); d.className='flame';
    d.style.left=Math.random()*100+'%';d.style.width=(2+Math.random()*3)+'px';
    d.style.height=(8+Math.random()*15)+'px';d.style.background=cols[Math.floor(Math.random()*cols.length)];
    d.style.animationDuration=(3+Math.random()*4)+'s';d.style.animationDelay=Math.random()*4+'s';
    c.appendChild(d);
  }
})();

// ===== API CALLS =====
async function api(path, opts={}) {
  try {
    const r = await fetch(API + path, {credentials:'same-origin', ...opts});
    return await r.json();
  } catch(e) { return {error: 'Erreur réseau'}; }
}

// ===== RENDER CARDS =====
function mkCard(m) {
  const bg = m.image_url ? `url(${m.image_url}) center/cover` : (m.bg_color||BG[0]);
  const d = document.createElement('div');
  d.className = 'mcard' + (m.is_trending==1?' trend':'');
  d.style.animationDelay = (Math.random()*.25)+'s';
  d.innerHTML = `
    <div class="mvis" style="background:${bg}">
      <div class="mpat"></div>
      ${m.is_trending==1?'<div class="tbadge">🔥 TREND</div>':''}
      <div class="sbadge">${SE[m.category]||'🎌'} ${SN[m.category]||'Anime'}</div>
      ${m.top_text?`<div class="mtop">${m.top_text}</div>`:''}
      <div class="moji">${m.emoji||'🎌'}</div>
      ${m.bot_text?`<div class="mbot">${m.bot_text}</div>`:''}
    </div>
    <div class="mmeta">
      <div class="mav">${(m.author||'?')[0].toUpperCase()}</div>
      <span class="maname">@${m.author||'Anonyme'}</span>
      <span class="mviews">👁️ ${m.views||0}</span>
    </div>
    <div class="mfoot">
      <span class="mtitle">${m.title}</span>
      <div class="macts">
        <button class="abt${m.user_liked==1?' liked':''}" onclick="doLike(${m.id},this)">❤️ <span>${m.likes_count||0}</span></button>
        <button class="abt${m.user_fired==1?' fired':''}" onclick="doFire(${m.id},this)">🔥 <span>${m.fires_count||0}</span></button>
        <button class="abt" onclick="togCom(${m.id})">💬 <span id="cc${m.id}">${m.comments_count||0}</span></button>
        <button class="abt" onclick="doShare(${m.id})">↗</button>
      </div>
    </div>
    <div class="mcoms" id="cm${m.id}">
      <div class="clist" id="cl${m.id}"></div>
      <div class="crow">
        <input class="cinp" type="text" placeholder="Ton commentaire..." id="ci${m.id}">
        <button class="csend" onclick="doComment(${m.id})">Envoyer</button>
      </div>
    </div>`;
  return d;
}

function render(gid, memes, append=false) {
  const g = document.getElementById(gid);
  if (!append) g.innerHTML = '';
  if (!memes || !memes.length) {
    if (!append) g.innerHTML = '<div style="color:var(--muted);text-align:center;padding:2rem;grid-column:1/-1">Aucun mème trouvé 🎌</div>';
    return;
  }
  memes.forEach(m => g.appendChild(mkCard(m)));
}

async function loadFeed(append=false) {
  if (!append) offset=0;
  const q = document.getElementById('srch')?.value||'';
  const data = await api(`memes.php?action=list&cat=${tag}&sort=${sort}&q=${encodeURIComponent(q)}&offset=${offset}&limit=12`);
  if (data.memes) render('feedG', data.memes, append);
  offset += 12;
}

async function loadTrend() {
  const data = await api('memes.php?action=list&sort=trending&limit=20');
  if (data.memes) render('trendG', data.memes);
}

async function loadStats() {
  const data = await api('memes.php?action=list&sort=new&limit=1000');
  if (data.memes) {
    document.getElementById('sTot').textContent = data.memes.length;
    document.getElementById('sLik').textContent = data.memes.reduce((a,m)=>a+(parseInt(m.likes_count)||0),0);
    document.getElementById('sVue').textContent = data.memes.reduce((a,m)=>a+(parseInt(m.views)||0),0);
  }
}

async function loadProfile() {
  if (!loggedIn) return;
  const data = await api('memes.php?action=list&sort=new&limit=50');
  // Note: en production, filtrer par user_id côté API
  if (data.memes) {
    render('profG', data.memes.slice(0,6));
    const me = await api('auth.php?action=me');
    if (me.user) {
      document.getElementById('pM').textContent = me.user.memes_count||0;
      document.getElementById('pL').textContent = me.user.total_likes||0;
      document.getElementById('pV').textContent = me.user.total_views||0;
    }
  }
}

// ===== INTERACTIONS =====
async function doLike(id, btn) {
  if (!loggedIn) { openMod(); toast('❌ Connecte-toi pour liker !','r'); return; }
  const data = await api('reactions.php?action=like', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({meme_id:id})});
  if (data.liked !== undefined) {
    btn.classList.toggle('liked', data.liked);
    btn.querySelector('span').textContent = data.total;
    toast(data.liked ? '❤️ Liké !' : 'Like retiré', data.liked?'r':'');
  }
}

async function doFire(id, btn) {
  if (!loggedIn) { openMod(); return; }
  const data = await api('reactions.php?action=fire', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({meme_id:id})});
  if (data.fired !== undefined) {
    btn.classList.toggle('fired', data.fired);
    btn.querySelector('span').textContent = data.total;
    toast(data.fired ? '🔥 En feu !' : 'Réaction retirée', 'gold');
  }
}

async function togCom(id) {
  const panel = document.getElementById('cm'+id);
  panel.classList.toggle('open');
  if (panel.classList.contains('open')) {
    const data = await api(`reactions.php?action=comments&meme_id=${id}`);
    const list = document.getElementById('cl'+id);
    list.innerHTML = '';
    (data.comments||[]).forEach(c => {
      const d = document.createElement('div'); d.className='ci';
      d.innerHTML = `<span class="cau">@${c.username}</span><span class="ct"> ${c.content}</span>`;
      list.appendChild(d);
    });
  }
}

async function doComment(id) {
  if (!loggedIn) { openMod(); return; }
  const inp = document.getElementById('ci'+id);
  const txt = inp.value.trim(); if (!txt) return;
  const data = await api('reactions.php?action=comment', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({meme_id:id, content:txt})});
  if (data.comment) {
    const list = document.getElementById('cl'+id);
    const d = document.createElement('div'); d.className='ci';
    d.innerHTML = `<span class="cau">@${data.comment.username}</span><span class="ct"> ${data.comment.content}</span>`;
    list.appendChild(d); inp.value='';
    const cc = document.getElementById('cc'+id);
    if (cc) cc.textContent = parseInt(cc.textContent)+1;
    toast('💬 Commentaire ajouté !','g');
  } else toast(data.error||'Erreur','r');
}

function doShare(id) {
  const url = window.location.origin + window.location.pathname + '?meme=' + id;
  navigator.clipboard?.writeText(url);
  toast('🔗 Lien copié !','g');
}

// ===== NAVIGATION =====
function goP(p) {
  document.querySelectorAll('.page').forEach(x=>x.classList.remove('active'));
  document.getElementById('page-'+p).classList.add('active');
  const tabs=['feed','trend','ai','up','prof'];
  document.querySelectorAll('.nav-tab').forEach((t,i)=>t.classList.toggle('active',tabs[i]===p));
  if (p==='trend') loadTrend();
  if (p==='prof') loadProfile();
}
function sbA(b){document.querySelectorAll('.sb-btn').forEach(x=>x.classList.remove('active'));b.classList.add('active');}
function setSort(b,s){sort=s;document.querySelectorAll('.sort-btn').forEach(x=>x.classList.remove('active'));b.classList.add('active');loadFeed();}
function doTag(el,t){tag=t;document.querySelectorAll('.tag').forEach(x=>x.classList.remove('active'));el.classList.add('active');loadFeed();}
function doSearch(){clearTimeout(doSearch._t);doSearch._t=setTimeout(loadFeed,350);}
function loadMore(){loadFeed(true);}

// ===== AI =====
function setC(el){document.getElementById('aiI').value=el.textContent.trim();}
function genAI() {
  const p=document.getElementById('aiI').value.trim();if(!p){toast('❌ Décris une scène !','r');return;}
  lastP=p;const btn=document.getElementById('aiBt');
  btn.disabled=true;btn.innerHTML='<div class="dots"><div class="dot"></div><div class="dot"></div><div class="dot"></div></div>';
  setTimeout(()=>{
    const lp=p.toLowerCase();
    let t=AI_T[Math.floor(Math.random()*AI_T.length)];
    if(lp.includes('tanjiro')||lp.includes('demon'))t=AI_T[0];
    else if(lp.includes('luffy'))t=AI_T[1];
    else if(lp.includes('goku')||lp.includes('dragon'))t=AI_T[2];
    else if(lp.includes('naruto'))t=AI_T[3];
    else if(lp.includes('mikasa')||lp.includes('eren'))t=AI_T[4];
    else if(lp.includes('gojo'))t=AI_T[5];
    else if(lp.includes('zoro'))t=AI_T[6];
    document.getElementById('aiT').textContent=t.top;
    document.getElementById('aiB').textContent=t.bot;
    document.getElementById('aiE').textContent=t.e;
    document.getElementById('aiPv').style.background=t.bg;
    document.getElementById('aiC').textContent='💡 '+t.cap+' — depuis "'+p+'"';
    document.getElementById('aiR').classList.add('show');
    btn.disabled=false;btn.textContent='⚡ GÉNÉRER';
    toast('🤖 Mème anime généré !','gold');
  },1800);
}
function reGen(){if(lastP){document.getElementById('aiI').value=lastP;genAI();}}
function saveAI(){toast('💾 Connecte-toi pour sauvegarder !','gold');if(!loggedIn)openMod();}
function shareAI(){navigator.clipboard?.writeText(window.location.href);toast('🔗 Lien copié !','g');}

// ===== UPLOAD =====
function selT(b){document.querySelectorAll('.tbtn').forEach(x=>x.classList.remove('active'));b.classList.add('active');}
function prevF(inp){
  const f=inp.files[0];if(!f)return;
  const r=new FileReader();r.onload=e=>{const i=document.getElementById('dprev');i.src=e.target.result;i.style.display='block';};
  r.readAsDataURL(f);
}
const dzEl=document.getElementById('dz');
if(dzEl){
  dzEl.addEventListener('dragover',e=>{e.preventDefault();dzEl.style.borderColor='var(--red)';});
  dzEl.addEventListener('dragleave',()=>dzEl.style.borderColor='');
  dzEl.addEventListener('drop',e=>{e.preventDefault();dzEl.style.borderColor='';const f=e.dataTransfer.files[0];if(f&&f.type.startsWith('image/')){const r=new FileReader();r.onload=ev=>{const i=document.getElementById('dprev');i.src=ev.target.result;i.style.display='block';};r.readAsDataURL(f);}});
}

async function doUpload() {
  if (!loggedIn) { openMod(); toast('❌ Connecte-toi pour uploader !','r'); return; }
  const title = document.getElementById('uT').value.trim();
  if (!title) { toast('❌ Titre obligatoire !','r'); return; }
  const fd = new FormData();
  fd.append('title', title);
  fd.append('top_text', document.getElementById('uTp').value);
  fd.append('bot_text', document.getElementById('uBt').value);
  fd.append('category', document.getElementById('uCat').value);
  const fi = document.getElementById('fI');
  if (fi.files[0]) fd.append('image', fi.files[0]);
  const data = await api('memes.php?action=create', {method:'POST', body:fd});
  if (data.success) {
    toast('🔥 Mème publié !','g');
    ['uT','uTp','uBt'].forEach(id=>{document.getElementById(id).value='';});
    document.getElementById('dprev').style.display='none';
    goP('feed'); loadFeed();
  } else toast(data.error||'Erreur upload','r');
}

// ===== AUTH =====
function openMod(){document.getElementById('mov').classList.add('open');}
function closeMod(){document.getElementById('mov').classList.remove('open');}
function swTab(t){
  document.getElementById('fL').style.display=t==='l'?'block':'none';
  document.getElementById('fR').style.display=t==='r'?'block':'none';
  document.getElementById('tL').classList.toggle('active',t==='l');
  document.getElementById('tR').classList.toggle('active',t==='r');
}

async function doLogin() {
  const u=document.getElementById('lU').value.trim(), p=document.getElementById('lP').value;
  if(!u||!p){toast('❌ Remplis tous les champs !','r');return;}
  const data = await api('auth.php?action=login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:u,password:p})});
  if(data.success){location.reload();}
  else toast(data.error||'Erreur connexion','r');
}

async function doReg() {
  const u=document.getElementById('rU').value.trim(), e=document.getElementById('rE').value.trim(), p=document.getElementById('rP').value;
  if(!u||!e||!p){toast('❌ Remplis tous les champs !','r');return;}
  const data = await api('auth.php?action=register',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:u,email:e,password:p})});
  if(data.success){location.reload();}
  else toast(data.error||'Erreur inscription','r');
}

async function doLogout() {
  await api('auth.php?action=logout');
  location.reload();
}

document.getElementById('mov').addEventListener('click',function(e){if(e.target===this)closeMod();});

// ===== TOAST =====
function toast(msg,type){
  const t=document.getElementById('toast');t.textContent=msg;
  t.className='toast show '+(type||'');
  clearTimeout(t._t);t._t=setTimeout(()=>t.classList.remove('show'),2600);
}

// ===== INIT =====
loadFeed();
loadStats();
</script>
</body>
</html>
