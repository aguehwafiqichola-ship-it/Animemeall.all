<?php
require_once '../config.php';

$action = $_GET['action'] ?? '';

// ===== INSCRIPTION =====
if ($action === 'register' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $username = clean($data['username'] ?? '');
    $email    = clean($data['email'] ?? '');
    $password = $data['password'] ?? '';

    if (strlen($username) < 3) json_out(['error' => 'Pseudo trop court (min 3 chars)'], 400);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) json_out(['error' => 'Email invalide'], 400);
    if (strlen($password) < 6) json_out(['error' => 'Mot de passe trop court (min 6 chars)'], 400);

    $pdo = db();
    $check = $pdo->prepare("SELECT id FROM users WHERE username=? OR email=?");
    $check->execute([$username, $email]);
    if ($check->fetch()) json_out(['error' => 'Pseudo ou email déjà utilisé'], 409);

    $hash = password_hash($password, PASSWORD_BCRYPT);
    $stmt = $pdo->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
    $stmt->execute([$username, $email, $hash]);
    $id = $pdo->lastInsertId();

    $_SESSION['user'] = ['id' => $id, 'username' => $username, 'email' => $email, 'role' => 'user'];
    json_out(['success' => true, 'user' => $_SESSION['user'], 'message' => "Bienvenue @$username ! 🎌"]);
}

// ===== CONNEXION =====
if ($action === 'login' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $username = clean($data['username'] ?? '');
    $password = $data['password'] ?? '';

    $stmt = db()->prepare("SELECT * FROM users WHERE username=?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password'])) {
        json_out(['error' => 'Pseudo ou mot de passe incorrect'], 401);
    }

    $_SESSION['user'] = [
        'id' => $user['id'],
        'username' => $user['username'],
        'email' => $user['email'],
        'role' => $user['role'],
        'bio' => $user['bio'],
        'avatar' => $user['avatar'],
    ];
    json_out(['success' => true, 'user' => $_SESSION['user']]);
}

// ===== DÉCONNEXION =====
if ($action === 'logout') {
    session_destroy();
    json_out(['success' => true]);
}

// ===== PROFIL =====
if ($action === 'me') {
    $u = current_user();
    if (!$u) json_out(['user' => null]);
    // Récupère les stats
    $pdo = db();
    $stats = $pdo->prepare("
        SELECT
            COUNT(m.id) as memes_count,
            COALESCE(SUM((SELECT COUNT(*) FROM likes WHERE meme_id=m.id)),0) as total_likes,
            COALESCE(SUM(m.views),0) as total_views
        FROM memes m WHERE m.user_id=?
    ");
    $stats->execute([$u['id']]);
    $s = $stats->fetch();
    json_out(['user' => array_merge($u, $s)]);
}

json_out(['error' => 'Action invalide'], 400);
