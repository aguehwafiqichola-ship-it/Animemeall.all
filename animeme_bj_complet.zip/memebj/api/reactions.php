<?php
require_once '../config.php';

$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];

// ===== TOGGLE LIKE ❤️ =====
if ($action === 'like' && $method === 'POST') {
    $user   = must_login();
    $data   = json_decode(file_get_contents('php://input'), true);
    $meme_id = (int)($data['meme_id'] ?? 0);

    $pdo  = db();
    $check = $pdo->prepare("SELECT id FROM likes WHERE meme_id=? AND user_id=?");
    $check->execute([$meme_id, $user['id']]);
    $existing = $check->fetch();

    if ($existing) {
        $pdo->prepare("DELETE FROM likes WHERE meme_id=? AND user_id=?")->execute([$meme_id, $user['id']]);
        $liked = false;
    } else {
        $pdo->prepare("INSERT INTO likes (meme_id, user_id) VALUES (?, ?)")->execute([$meme_id, $user['id']]);
        $liked = true;
    }

    $count = $pdo->prepare("SELECT COUNT(*) FROM likes WHERE meme_id=?");
    $count->execute([$meme_id]);
    $total = $count->fetchColumn();

    json_out(['liked' => $liked, 'total' => $total]);
}

// ===== TOGGLE FEU 🔥 =====
if ($action === 'fire' && $method === 'POST') {
    $user    = must_login();
    $data    = json_decode(file_get_contents('php://input'), true);
    $meme_id = (int)($data['meme_id'] ?? 0);

    $pdo   = db();
    $check = $pdo->prepare("SELECT id FROM fires WHERE meme_id=? AND user_id=?");
    $check->execute([$meme_id, $user['id']]);

    if ($check->fetch()) {
        $pdo->prepare("DELETE FROM fires WHERE meme_id=? AND user_id=?")->execute([$meme_id, $user['id']]);
        $fired = false;
    } else {
        $pdo->prepare("INSERT INTO fires (meme_id, user_id) VALUES (?, ?)")->execute([$meme_id, $user['id']]);
        $fired = true;
    }

    $count = $pdo->prepare("SELECT COUNT(*) FROM fires WHERE meme_id=?");
    $count->execute([$meme_id]);

    json_out(['fired' => $fired, 'total' => $count->fetchColumn()]);
}

// ===== AJOUTER UN COMMENTAIRE 💬 =====
if ($action === 'comment' && $method === 'POST') {
    $user    = must_login();
    $data    = json_decode(file_get_contents('php://input'), true);
    $meme_id = (int)($data['meme_id'] ?? 0);
    $content = clean($data['content'] ?? '');

    if (!$content) json_out(['error' => 'Commentaire vide'], 400);
    if (strlen($content) > 500) json_out(['error' => 'Commentaire trop long (max 500 chars)'], 400);

    $pdo = db();
    $stmt = $pdo->prepare("INSERT INTO comments (meme_id, user_id, content) VALUES (?, ?, ?)");
    $stmt->execute([$meme_id, $user['id'], $content]);

    json_out([
        'success'  => true,
        'comment'  => [
            'id'       => $pdo->lastInsertId(),
            'username' => $user['username'],
            'content'  => $content,
            'created_at' => date('Y-m-d H:i:s'),
        ]
    ]);
}

// ===== LISTE COMMENTAIRES =====
if ($action === 'comments' && $method === 'GET') {
    $meme_id = (int)($_GET['meme_id'] ?? 0);
    $stmt = db()->prepare("
        SELECT c.id, c.content, c.created_at, u.username, u.avatar
        FROM comments c JOIN users u ON u.id=c.user_id
        WHERE c.meme_id=? ORDER BY c.created_at ASC
    ");
    $stmt->execute([$meme_id]);
    json_out(['comments' => $stmt->fetchAll()]);
}

json_out(['error' => 'Action invalide'], 400);
