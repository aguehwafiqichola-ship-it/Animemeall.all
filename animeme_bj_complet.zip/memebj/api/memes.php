<?php
require_once '../config.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

// ===== LISTE DES MÈMES =====
if ($action === 'list' && $method === 'GET') {
    $cat    = $_GET['cat'] ?? 'all';
    $sort   = $_GET['sort'] ?? 'new';  // new | top | trending
    $search = clean($_GET['q'] ?? '');
    $limit  = (int)($_GET['limit'] ?? 12);
    $offset = (int)($_GET['offset'] ?? 0);
    $uid    = current_user()['id'] ?? 0;

    $where = [];
    $params = [];

    if ($cat !== 'all') { $where[] = 'm.category = ?'; $params[] = $cat; }
    if ($sort === 'trending') { $where[] = 'm.is_trending = 1'; }
    if ($search) {
        $where[] = '(m.title LIKE ? OR m.top_text LIKE ? OR m.bot_text LIKE ?)';
        $s = "%$search%";
        array_push($params, $s, $s, $s);
    }

    $whereStr = $where ? 'WHERE ' . implode(' AND ', $where) : '';

    $orderBy = match($sort) {
        'top'      => 'likes_count DESC',
        'trending' => 'likes_count DESC',
        default    => 'm.created_at DESC',
    };

    $sql = "
        SELECT
            m.*,
            u.username AS author,
            u.avatar   AS author_avatar,
            COUNT(DISTINCT l.id)  AS likes_count,
            COUNT(DISTINCT f.id)  AS fires_count,
            COUNT(DISTINCT c.id)  AS comments_count,
            MAX(CASE WHEN l.user_id = $uid THEN 1 ELSE 0 END) AS user_liked,
            MAX(CASE WHEN f.user_id = $uid THEN 1 ELSE 0 END) AS user_fired
        FROM memes m
        JOIN users u ON u.id = m.user_id
        LEFT JOIN likes l ON l.meme_id = m.id
        LEFT JOIN fires f ON f.meme_id = m.id
        LEFT JOIN comments c ON c.meme_id = m.id
        $whereStr
        GROUP BY m.id
        ORDER BY $orderBy
        LIMIT $limit OFFSET $offset
    ";

    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    $memes = $stmt->fetchAll();

    // Incrémenter les vues
    if ($memes) {
        $ids = implode(',', array_column($memes, 'id'));
        db()->exec("UPDATE memes SET views = views + 1 WHERE id IN ($ids)");
    }

    json_out(['memes' => $memes, 'total' => count($memes)]);
}

// ===== UN SEUL MÈME =====
if ($action === 'get' && $method === 'GET') {
    $id  = (int)($_GET['id'] ?? 0);
    $uid = current_user()['id'] ?? 0;

    $stmt = db()->prepare("
        SELECT m.*, u.username AS author, u.avatar AS author_avatar,
            COUNT(DISTINCT l.id) AS likes_count,
            COUNT(DISTINCT f.id) AS fires_count,
            MAX(CASE WHEN l.user_id=? THEN 1 ELSE 0 END) AS user_liked,
            MAX(CASE WHEN f.user_id=? THEN 1 ELSE 0 END) AS user_fired
        FROM memes m JOIN users u ON u.id=m.user_id
        LEFT JOIN likes l ON l.meme_id=m.id
        LEFT JOIN fires f ON f.meme_id=m.id
        WHERE m.id=? GROUP BY m.id
    ");
    $stmt->execute([$uid, $uid, $id]);
    $meme = $stmt->fetch();
    if (!$meme) json_out(['error' => 'Mème introuvable'], 404);

    // Commentaires
    $cmt = db()->prepare("SELECT c.*, u.username FROM comments c JOIN users u ON u.id=c.user_id WHERE c.meme_id=? ORDER BY c.created_at ASC");
    $cmt->execute([$id]);
    $meme['comments'] = $cmt->fetchAll();

    json_out(['meme' => $meme]);
}

// ===== CRÉER UN MÈME =====
if ($action === 'create' && $method === 'POST') {
    $user = must_login();

    // Upload image si présente
    $image_url = null;
    if (!empty($_FILES['image'])) {
        $file = $_FILES['image'];
        if ($file['size'] > MAX_FILE_SIZE) json_out(['error' => 'Fichier trop lourd (max 10MB)'], 400);
        if (!in_array($file['type'], ALLOWED_TYPES)) json_out(['error' => 'Format non autorisé'], 400);

        $ext  = pathinfo($file['name'], PATHINFO_EXTENSION);
        $name = uniqid('meme_', true) . '.' . $ext;
        $dest = UPLOAD_DIR . $name;

        if (!move_uploaded_file($file['tmp_name'], $dest)) json_out(['error' => 'Erreur upload'], 500);
        $image_url = UPLOAD_URL . $name;
    }

    $cats = ['all','ds','op','aot','nrt','jjk','hxh','db','bl'];
    $emojis = ['ds'=>'⚔️','op'=>'🏴‍☠️','aot'=>'🌑','nrt'=>'🍃','jjk'=>'💜','hxh'=>'⭐','db'=>'💥','bl'=>'⚡','all'=>'🎌'];
    $bgs = [
        'linear-gradient(135deg,#0d0d30,#1a0a20)',
        'linear-gradient(135deg,#200a0a,#0d0d20)',
        'linear-gradient(135deg,#0a2010,#0d1a30)',
        'linear-gradient(135deg,#1a0a30,#0a1020)',
        'linear-gradient(135deg,#200a10,#0a0a20)',
        'linear-gradient(135deg,#0a1030,#200a20)',
    ];

    $title    = clean($_POST['title'] ?? '');
    $top_text = clean($_POST['top_text'] ?? '');
    $bot_text = clean($_POST['bot_text'] ?? '');
    $category = in_array($_POST['category'] ?? '', $cats) ? $_POST['category'] : 'all';
    $emoji    = $emojis[$category] ?? '🎌';
    $bg       = $bgs[array_rand($bgs)];

    if (!$title) json_out(['error' => 'Titre obligatoire'], 400);

    $stmt = db()->prepare("
        INSERT INTO memes (user_id, title, top_text, bot_text, emoji, category, image_url, bg_color)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([$user['id'], $title, $top_text, $bot_text, $emoji, $category, $image_url, $bg]);

    json_out(['success' => true, 'id' => db()->lastInsertId(), 'message' => 'Mème publié ! 🔥']);
}

// ===== SUPPRIMER UN MÈME =====
if ($action === 'delete' && $method === 'DELETE') {
    $user = must_login();
    $id   = (int)($_GET['id'] ?? 0);

    $stmt = db()->prepare("SELECT user_id, image_url FROM memes WHERE id=?");
    $stmt->execute([$id]);
    $meme = $stmt->fetch();
    if (!$meme) json_out(['error' => 'Mème introuvable'], 404);
    if ($meme['user_id'] != $user['id'] && $user['role'] !== 'admin') json_out(['error' => 'Non autorisé'], 403);

    // Supprimer l'image
    if ($meme['image_url']) {
        $file = UPLOAD_DIR . basename($meme['image_url']);
        if (file_exists($file)) unlink($file);
    }

    db()->prepare("DELETE FROM memes WHERE id=?")->execute([$id]);
    json_out(['success' => true]);
}

json_out(['error' => 'Action invalide'], 400);
