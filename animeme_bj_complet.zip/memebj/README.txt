╔══════════════════════════════════════════════════════════════╗
║          ⚔️  ANIMEME.BJ — GUIDE D'INSTALLATION              ║
║         Site de Mèmes Anime/Manga — Version PHP+MySQL        ║
╚══════════════════════════════════════════════════════════════╝

═══════════════════════════════════════
 📁 STRUCTURE DES FICHIERS
═══════════════════════════════════════

animeme/
├── index.php          ← Page principale (tout le site)
├── config.php         ← Configuration DB + fonctions
├── setup.sql          ← Script création base de données
├── README.txt         ← Ce fichier
├── uploads/           ← Images uploadées (créer ce dossier !)
└── api/
    ├── auth.php       ← Connexion / Inscription / Profil
    ├── memes.php      ← Créer / Lire / Supprimer mèmes
    └── reactions.php  ← Likes, Feux 🔥, Commentaires

═══════════════════════════════════════
 🚀 INSTALLATION EN 5 ÉTAPES
═══════════════════════════════════════

ÉTAPE 1 — Crée la base de données
──────────────────────────────────
  Option A (phpMyAdmin) :
    1. Ouvre phpMyAdmin
    2. Clique "Nouvelle base de données"
    3. Nom : animeme_db — Collation : utf8mb4_unicode_ci
    4. Clique "Importer" → sélectionne setup.sql
    5. Clique "Exécuter"

  Option B (Terminal) :
    mysql -u root -p < setup.sql

ÉTAPE 2 — Configure config.php
───────────────────────────────
  Ouvre config.php et modifie :

    define('DB_USER', 'ton_user_mysql');
    define('DB_PASS', 'ton_mot_de_passe');
    define('SITE_URL', 'https://ton-domaine.com/animeme');

ÉTAPE 3 — Upload les fichiers
──────────────────────────────
  Copie tous les fichiers sur ton hébergeur via :
    - FTP (FileZilla, Cyberduck)
    - cPanel File Manager
    - SSH : scp -r animeme/ user@host:/var/www/html/

ÉTAPE 4 — Permissions uploads/
────────────────────────────────
  Le dossier uploads/ doit être accessible en écriture :

  Via FTP : clic droit → permissions → 755
  Via terminal : chmod 755 uploads/

ÉTAPE 5 — Teste le site !
──────────────────────────
  Ouvre : http://ton-domaine.com/animeme/

═══════════════════════════════════════
 🛠️ HÉBERGEURS COMPATIBLES
═══════════════════════════════════════

✅ InfinityFree (gratuit)       → https://infinityfree.net
✅ 000webhost (gratuit)         → https://www.000webhost.com
✅ Hostinger                    → https://www.hostinger.fr
✅ OVH                          → https://www.ovh.com
✅ XAMPP / WAMP (local)

PHP requis : 7.4+
MySQL requis : 5.7+

═══════════════════════════════════════
 🔥 FONCTIONNALITÉS INCLUSES
═══════════════════════════════════════

✅ Feed de mèmes avec scroll
✅ Upload image (PNG, JPG, GIF, WEBP)
✅ Texte haut/bas style mème classique
✅ Catégories par série anime
✅ Likes ❤️ et réactions Feu 🔥
✅ Commentaires 💬 en temps réel
✅ Trending — mèmes populaires
✅ Recherche par titre
✅ Tri par date ou popularité
✅ Inscription / Connexion sécurisée
✅ Profil avec stats personnelles
✅ Générateur IA de mèmes
✅ Design dark épique style Demon Slayer

═══════════════════════════════════════
 💰 MONÉTISATION (conseils)
═══════════════════════════════════════

1. Google AdSense — pub automatique
2. Publicité directe — marques anime
3. Compte TikTok/Instagram lié au site
4. Boutique merch anime (Printful)
5. Donations — KoFi ou PayPal

═══════════════════════════════════════
 📞 SUPPORT
═══════════════════════════════════════

Si tu as des problèmes :
- Vérifie les logs PHP : error_log dans ton hébergeur
- Active les erreurs PHP en dev :
    ini_set('display_errors', 1);
    error_reporting(E_ALL);
  (à ajouter temporairement dans config.php)

Bonne chance ! ⚔️🔥
