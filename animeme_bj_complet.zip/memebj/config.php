<?php
// ============================================
// ANIMEME.BJ — Configuration
// Modifie DB_USER et DB_PASS selon ton hébergeur
// ============================================
define('DB_HOST', 'localhost');
define('DB_NAME', 'animeme_db');
define('DB_USER', 'root');
define('DB_PASS', '');
define('SITE_URL', 'http://localhost/animeme');
define('UPLOAD_DIR', __DIR__ . '/uploads/');
define('UPLOAD_URL', SITE_URL . '/uploads/');
define('MAX_FILE_SIZE', 10 * 1024 * 1024);
define('ALLOWED_TYPES', ['image/jpeg','image/png','image/gif','image/webp']);

if (session_status() === PHP_SESSION_NONE) session_start();

function db() {
    static $pdo = null;
    if (!$pdo) {
        try {
            $pdo = new PDO(
                "mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4",
                DB_USER, DB_PASS,
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                 PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
            );
        } catch (PDOException $e) {
            die("Erreur DB: " . $e->getMessage());
        }
    }
    return $pdo;
}

function json_out($data, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function current_user() {
    return $_SESSION['user'] ?? null;
}

function must_login() {
    if (!current_user()) json_out(['error' => 'Connexion requise'], 401);
    return current_user();
}

function clean($s) {
    return htmlspecialchars(trim($s), ENT_QUOTES, 'UTF-8');
}
